import { createRouter, createWebHistory } from 'vue-router'

const routes = [
  {
    path: '/',
    component: () => import('../views/Layout.vue'),
    redirect: '/dashboard',
    children: [
      { path: 'dashboard', name: 'Dashboard', component: () => import('../views/dashboard/Dashboard.vue'), meta: { title: '系统概览' } },
      // 申请管理
      { path: 'application/submit', name: 'ApplicationSubmit', component: () => import('../views/application/ApplicationSubmit.vue'), meta: { title: '提交申请' } },
      { path: 'application/list', name: 'ApplicationList', component: () => import('../views/application/ApplicationList.vue'), meta: { title: '申请列表' } },
      { path: 'application/queue', name: 'AllocationQueue', component: () => import('../views/application/AllocationQueue.vue'), meta: { title: '分房队列' } },
      // 房产信息
      { path: 'house/list', name: 'HouseList', component: () => import('../views/house/HouseList.vue'), meta: { title: '房产列表' } },
      { path: 'house/available', name: 'AvailableHouses', component: () => import('../views/house/AvailableHouses.vue'), meta: { title: '空闲房产' } },
      // 住户管理
      { path: 'resident/list', name: 'ResidentList', component: () => import('../views/resident/ResidentList.vue'), meta: { title: '住户列表' } },
      { path: 'resident/bill', name: 'BillList', component: () => import('../views/resident/BillList.vue'), meta: { title: '房租账单' } },
      // 管理功能
      { path: 'admin/statistics', name: 'Statistics', component: () => import('../views/admin/Statistics.vue'), meta: { title: '统计报表' } },
      { path: 'admin/threshold', name: 'ThresholdManage', component: () => import('../views/admin/ThresholdManage.vue'), meta: { title: '阈值管理' } },
      { path: 'admin/rent', name: 'RentManage', component: () => import('../views/admin/RentManage.vue'), meta: { title: '租金管理' } },
    ]
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

export default router
