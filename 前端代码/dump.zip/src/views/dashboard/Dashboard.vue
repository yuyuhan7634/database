<template>
  <div class="dashboard">
    <h2 class="page-title">系统概览</h2>

    <!-- 统计卡片 -->
    <el-row :gutter="20" class="stat-cards">
      <el-col :span="6">
        <el-card shadow="hover" class="stat-card">
          <div class="stat-value">{{ stats.totalHouses || 0 }}</div>
          <div class="stat-label">房屋总数</div>
        </el-card>
      </el-col>
      <el-col :span="6">
        <el-card shadow="hover" class="stat-card">
          <div class="stat-value" style="color:#67c23a">{{ stats.emptyHouses || 0 }}</div>
          <div class="stat-label">空闲房屋</div>
        </el-card>
      </el-col>
      <el-col :span="6">
        <el-card shadow="hover" class="stat-card">
          <div class="stat-value" style="color:#409eff">{{ stats.occupiedHouses || 0 }}</div>
          <div class="stat-label">已分配房屋</div>
        </el-card>
      </el-col>
      <el-col :span="6">
        <el-card shadow="hover" class="stat-card">
          <div class="stat-value" style="color:#e6a23c">{{ stats.occupancyRate || '0%' }}</div>
          <div class="stat-label">入住率</div>
        </el-card>
      </el-col>
    </el-row>

    <!-- 功能快捷入口 -->
    <el-row :gutter="20" class="quick-actions">
      <el-col :span="24">
        <el-card shadow="never">
          <template #header><span>快捷操作</span></template>
          <el-row :gutter="20">
            <el-col :span="4" v-for="item in quickActions" :key="item.path">
              <el-card shadow="hover" class="quick-card" @click="$router.push(item.path)">
                <el-icon :size="32" :color="item.color"><component :is="item.icon" /></el-icon>
                <div class="quick-name">{{ item.name }}</div>
              </el-card>
            </el-col>
          </el-row>
        </el-card>
      </el-col>
    </el-row>

    <!-- 住房标准阈值 -->
    <el-card shadow="never" class="section-card">
      <template #header><span>住房标准阈值</span></template>
      <el-table :data="standards" stripe style="width:100%">
        <el-table-column prop="area" label="面积 (㎡)" width="200" />
        <el-table-column prop="minScore" label="最低分数" />
      </el-table>
    </el-card>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { getStatistics } from '../../api/admin'
import { getStandardList } from '../../api/house'

const stats = ref({})
const standards = ref([])

const quickActions = [
  { path: '/application/submit', name: '提交申请', icon: 'Edit', color: '#409eff' },
  { path: '/application/queue', name: '分房队列', icon: 'Sort', color: '#67c23a' },
  { path: '/house/available', name: '空闲房产', icon: 'HomeFilled', color: '#e6a23c' },
  { path: '/resident/bill', name: '房租账单', icon: 'Money', color: '#f56c6c' },
  { path: '/admin/statistics', name: '统计报表', icon: 'DataBoard', color: '#909399' },
]

onMounted(async () => {
  try {
    const [statsRes, stdRes] = await Promise.all([
      getStatistics(), getStandardList()
    ])
    stats.value = statsRes.data || {}
    standards.value = stdRes.data || []
  } catch (e) { /* errors handled by interceptor */ }
})
</script>

<style scoped>
.page-title { margin: 0 0 20px; font-size: 22px; color: #303133; }
.stat-cards { margin-bottom: 20px; }
.stat-card { text-align: center; cursor: default; }
.stat-value { font-size: 36px; font-weight: bold; color: #303133; }
.stat-label { font-size: 14px; color: #909399; margin-top: 8px; }
.quick-actions { margin-bottom: 20px; }
.quick-card { text-align: center; cursor: pointer; transition: transform .2s; }
.quick-card:hover { transform: translateY(-3px); }
.quick-name { margin-top: 10px; font-size: 14px; color: #606266; }
.section-card { margin-bottom: 20px; }
</style>
