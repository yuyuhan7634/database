<template>
  <div class="available-houses">
    <h2 class="page-title">空闲房产</h2>
    <el-card shadow="never">
      <template #header>
        <span>当前空闲房屋（可分配）</span>
        <el-tag type="success" style="margin-left:12px">{{ list.length }} 套</el-tag>
        <el-button type="primary" size="small" @click="fetchData" style="float:right">刷新</el-button>
      </template>
      <el-table :data="list" stripe v-loading="loading" style="width:100%">
        <el-table-column prop="houseNo" label="房号" width="200" />
        <el-table-column prop="area" label="面积 (㎡)" width="120" />
        <el-table-column prop="rentPerSqm" label="每平米房租 (元)" width="150" />
        <el-table-column label="预计月租金" width="150">
          <template #default="{ row }">{{ (row.area * row.rentPerSqm).toFixed(2) }} 元</template>
        </el-table-column>
      </el-table>
      <el-empty v-if="!loading && list.length === 0" description="暂无空闲房屋" />
    </el-card>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { getAvailableHouses } from '../../api/house'

const list = ref([])
const loading = ref(false)

async function fetchData() {
  loading.value = true
  try {
    const res = await getAvailableHouses()
    list.value = res.data || []
  } catch (e) {}
  loading.value = false
}

onMounted(fetchData)
</script>

<style scoped>
.page-title { margin: 0 0 20px; font-size: 22px; }
</style>
