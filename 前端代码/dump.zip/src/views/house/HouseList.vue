<template>
  <div class="house-list">
    <h2 class="page-title">房产列表</h2>
    <el-card shadow="never">
      <template #header>
        <span>全部房屋信息</span>
        <el-button type="primary" size="small" @click="fetchData" style="float:right">刷新</el-button>
      </template>
      <el-table :data="list" stripe v-loading="loading" style="width:100%">
        <el-table-column prop="houseNo" label="房号" width="180" />
        <el-table-column prop="area" label="面积 (㎡)" width="120">
          <template #default="{ row }">{{ row.area }} ㎡</template>
        </el-table-column>
        <el-table-column prop="rentPerSqm" label="每平米房租 (元)" width="150">
          <template #default="{ row }">{{ row.rentPerSqm }} 元/㎡</template>
        </el-table-column>
        <el-table-column label="状态" width="120">
          <template #default="{ row }">
            <el-tag :type="row.status === 0 ? 'success' : 'danger'" size="small">
              {{ row.status === 0 ? '空闲' : '已分配' }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="月租金" width="120">
          <template #default="{ row }">
            {{ (row.area * row.rentPerSqm).toFixed(2) }} 元
          </template>
        </el-table-column>
        <el-table-column label="操作" width="120">
          <template #default="{ row }">
            <el-button size="small" @click="showDetail(row)">详情</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <!-- 房屋详情弹窗 -->
    <el-dialog v-model="detailVisible" title="房屋详情" width="400px">
      <el-descriptions :column="1" border v-if="detail">
        <el-descriptions-item label="房号">{{ detail.houseNo }}</el-descriptions-item>
        <el-descriptions-item label="面积">{{ detail.area }} ㎡</el-descriptions-item>
        <el-descriptions-item label="每平米房租">{{ detail.rentPerSqm }} 元</el-descriptions-item>
        <el-descriptions-item label="月租金">{{ (detail.area * detail.rentPerSqm).toFixed(2) }} 元</el-descriptions-item>
        <el-descriptions-item label="状态">
          <el-tag :type="detail.status === 0 ? 'success' : 'danger'" size="small">
            {{ detail.status === 0 ? '空闲' : '已分配' }}
          </el-tag>
        </el-descriptions-item>
      </el-descriptions>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { getHouseList } from '../../api/house'

const list = ref([])
const loading = ref(false)
const detailVisible = ref(false)
const detail = ref(null)

async function fetchData() {
  loading.value = true
  try {
    const res = await getHouseList()
    list.value = res.data || []
  } catch (e) {}
  loading.value = false
}

function showDetail(row) {
  detail.value = row
  detailVisible.value = true
}

onMounted(fetchData)
</script>

<style scoped>
.page-title { margin: 0 0 20px; font-size: 22px; }
</style>
