<template>
  <div class="app-list">
    <h2 class="page-title">申请列表</h2>
    <el-card shadow="never">
      <template #header>
        <span>所有申请单</span>
        <el-button type="primary" size="small" @click="fetchData" style="float:right">刷新</el-button>
      </template>
      <el-table :data="list" stripe v-loading="loading" style="width:100%">
        <el-table-column prop="applyNo" label="申请编号" width="190" />
        <el-table-column prop="applicantName" label="申请人" width="100" />
        <el-table-column prop="department" label="部门" width="150" />
        <el-table-column label="类型" width="80">
          <template #default="{ row }">
            <el-tag :type="row.applyType === 1 ? 'primary' : row.applyType === 2 ? 'warning' : 'info'" size="small">
              {{ { 1: '分房', 2: '调房', 3: '退房' }[row.applyType] }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="状态" width="90">
          <template #default="{ row }">
            <el-tag :type="row.applyStatus === 0 ? 'warning' : row.applyStatus === 1 ? 'success' : 'danger'" size="small">
              {{ { 0: '待处理', 1: '已通过', 2: '已驳回' }[row.applyStatus] }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="score" label="分数" width="70" />
        <el-table-column prop="reqArea" label="要求面积" width="100">
          <template #default="{ row }">{{ row.reqArea ? row.reqArea + ' ㎡' : '-' }}</template>
        </el-table-column>
        <el-table-column prop="allocatedHouseNo" label="分配房号" width="130" />
        <el-table-column prop="createTime" label="创建时间" width="170">
          <template #default="{ row }">{{ formatTime(row.createTime) }}</template>
        </el-table-column>
        <el-table-column prop="rejectReason" label="驳回原因" min-width="150">
          <template #default="{ row }">
            <el-tooltip v-if="row.rejectReason" :content="row.rejectReason">
              <el-text type="danger" truncated>{{ row.rejectReason }}</el-text>
            </el-tooltip>
            <span v-else>-</span>
          </template>
        </el-table-column>
      </el-table>
    </el-card>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { getApplicationList } from '../../api/application'

const list = ref([])
const loading = ref(false)

function formatTime(t) {
  if (!t) return '-'
  return t.replace('T', ' ')
}

async function fetchData() {
  loading.value = true
  try {
    const res = await getApplicationList()
    list.value = res.data || []
  } catch (e) {}
  loading.value = false
}

onMounted(fetchData)
</script>

<style scoped>
.page-title { margin: 0 0 20px; font-size: 22px; }
</style>
