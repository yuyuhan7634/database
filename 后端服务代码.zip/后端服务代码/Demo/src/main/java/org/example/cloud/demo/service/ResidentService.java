package org.example.cloud.demo.service;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import org.example.cloud.demo.entity.House;
import org.example.cloud.demo.entity.RentBill;
import org.example.cloud.demo.entity.Resident;
import org.example.cloud.demo.mapper.HouseMapper;
import org.example.cloud.demo.mapper.RentBillMapper;
import org.example.cloud.demo.mapper.ResidentMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

/**
 * 住户服务（住户信息管理 + 房租账单管理）
 */
@Service
public class ResidentService {

    @Autowired
    private ResidentMapper residentMapper;

    @Autowired
    private RentBillMapper rentBillMapper;

    @Autowired
    private HouseMapper houseMapper;

    // ================== 住户管理 ==================

    @Cacheable(value = "residents", key = "'all'")
    public List<Resident> getAllResidents() {
        return residentMapper.selectList(null);
    }

    public Resident getResidentByName(String ownerName) {
        QueryWrapper<Resident> query = new QueryWrapper<>();
        query.eq("owner_name", ownerName);
        return residentMapper.selectOne(query);
    }

    public Resident getResidentByHouseNo(String houseNo) {
        QueryWrapper<Resident> query = new QueryWrapper<>();
        query.eq("house_no", houseNo);
        return residentMapper.selectOne(query);
    }

    @CacheEvict(value = "residents", allEntries = true)
    public void updateResident(Resident resident) {
        residentMapper.updateById(resident);
    }

    @CacheEvict(value = "residents", allEntries = true)
    public void saveResident(Resident resident) {
        residentMapper.insert(resident);
    }

    @CacheEvict(value = "residents", allEntries = true)
    public void removeResidentByNameAndHouse(String ownerName, String houseNo) {
        QueryWrapper<Resident> query = new QueryWrapper<>();
        query.eq("owner_name", ownerName).eq("house_no", houseNo);
        residentMapper.delete(query);
    }

    // ================== 房租账单管理 ==================

    @Cacheable(value = "bills", key = "'all'")
    public List<RentBill> getAllBills() {
        return rentBillMapper.selectList(
                new QueryWrapper<RentBill>().orderByDesc("bill_month").orderByAsc("house_no")
        );
    }

    @CacheEvict(value = "bills", allEntries = true)
    public void deleteBillsByNameAndHouse(String ownerName, String houseNo) {
        QueryWrapper<RentBill> query = new QueryWrapper<>();
        query.eq("owner_name", ownerName).eq("house_no", houseNo);
        rentBillMapper.delete(query);
    }

    @Transactional(rollbackFor = Exception.class)
    @CacheEvict(value = "bills", allEntries = true)
    public int generateMonthlyBills(String month) {
        int count = 0;
        QueryWrapper<House> houseQuery = new QueryWrapper<>();
        houseQuery.eq("status", 1);
        List<House> occupiedHouses = houseMapper.selectList(houseQuery);

        for (House house : occupiedHouses) {
            Resident resident = getResidentByHouseNo(house.getHouseNo());
            if (resident != null) {
                QueryWrapper<RentBill> billQuery = new QueryWrapper<>();
                billQuery.eq("house_no", house.getHouseNo()).eq("bill_month", month);
                if (rentBillMapper.selectCount(billQuery) == 0) {
                    BigDecimal rentAmount = house.getArea().multiply(house.getRentPerSqm());
                    RentBill bill = new RentBill();
                    bill.setHouseNo(house.getHouseNo());
                    bill.setOwnerName(resident.getOwnerName());
                    bill.setBillMonth(month);
                    bill.setRentAmount(rentAmount);
                    bill.setCreateTime(LocalDate.now());
                    rentBillMapper.insert(bill);
                    count++;
                }
            }
        }
        return count;
    }
}
